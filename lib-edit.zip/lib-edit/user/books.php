<?php
include "connection.php";
include "navbar.php";
if(!$_SESSION['login_user']){
    header("location:user_login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta charset="utf-8">
      <link rel="stylesheet" type="style/css" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    </head>
    <body>
    <style type="text/css">
        .srch{
            padding-left: 1000px;
        }
        body {
  background-color: gray;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #222;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.container{
   height: 500px;
    background-color: white;
    color: black;
}

.scroll{
            width: 100%;
            height: 400px;
            overflow: auto;
}

    </style>
        <!---sidenav--->

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

  <div style="color: white; margin-left: 60px; font-size: 20px;">

       <?php
       if(isset($_SESSION['login_user']))
           echo    " Welcome<br> ".$_SESSION['login_user'];
          
          ?>

 </div><br><br>

  <div class="h"><a href="index.php"><li style="font: 20px;" class="fas fa-house-user">Home</li></a></div>
  <div class="h"><a href="books.php"><li class = "bi bi-bookshelf">books</li></a></div>
  <div class="h"><a href="feedback.php"><li class = "bi bi-chat-left-text">feedback</li></a></div>
  <div class="h"><a href="profile.php"><li class = "bi bi-people">Profile</li></a></div>
  <div class="h"><a href="issue_info.php"><li class="bi bi-people">Issued Information</li></a></div>
  <div class="h"><a href="logout.php"><span class="glyphicon glyphicon-log-out"> Logout</span></a></div>
  
</div>
        
<div id="main">
  
  <span style="font-size:20px; color: white; cursor:pointer" onclick="openNav()">&#9776;Dashboard</span> <br>



<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "220px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "gray";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "gray";
}
</script>

<!---------------Search bar------------------>

<div class="srch">
    <form class="navbar-form" method="post" name="form1">
        
            <input class="form-control" type="text" name="search" placeholder="Search Books..." required="">
            <button style="background-color: #309d90;" type="submit" name="submit" class="btn btn-default">
                <span class="glyphicon glyphicon-search"></span>
            </button>     
    </form>   
</div>
<!-------Request Book-------->

<div class="srch">
    <form class="navbar-form" method="post" name="form1">
            <input class="form-control" type="text" name="bid" placeholder="Enter Book ID.." required="">
            <button style="background-color: #309d90;" type="submit" name="submit1" class="btn btn-default">Request</button>     
    </form>   
</div>
<div class="container"> <br>
<?php 
  if(isset($_GET['msg'])){
    ?>
      <alert class="alert alert-info"><?php echo $_GET['msg']; ?></alert>
    <?php
  }
?>
<h4>List Of Books</h4>
<div class="scroll">
<?php
if(isset($_POST['submit']))

{
$q=mysqli_query($db,"SELECT * from books where name like '%$_POST[search]%'");
if(mysqli_num_rows($q)==0)
{
echo "Sorry! No Books found. Try again";
}
else{
  echo "<table class='table table-bordered table-hover'>";
  echo "<tr style='background-color: gray;'>";
//Table Header
echo "<th>";    echo "ID";            echo "</th>";
echo "<th>";    echo "Book-Name";     echo "</th>";
echo "<th>";    echo "Author-Name";   echo "</th>";
echo "<th>";    echo "Edition";       echo "</th>";
echo "<th>";    echo "Status";        echo "</th>";
echo "<th>";    echo "Quantity";      echo "</th>";
echo "<th>";    echo "Action";      echo "</th>";
echo "</tr>";

while($row=mysqli_fetch_assoc($q))
{
    echo "<tr>";

    echo "<td>";    echo $row['bid'];    echo "</td>";
    echo "<td>";    echo $row['name'];    echo "</td>";
    echo "<td>";    echo $row['author'];    echo "</td>";
    echo "<td>";    echo $row['edition'];    echo "</td>";
    echo "<td>";    echo $row['status'];    echo "</td>";
    echo "<td>";    echo $row['quantity'];    echo "</td>";

    echo "<td>";    
    echo "<a style='background-color: blue;' href='view_book?bid=".$row['bid']."' class='btn btn-danger'>view</a>";
    echo "<a style='background-color: red;' href='request.php?bid=".$row['bid']."' class='btn btn-danger'>Request</a> ";
    echo "<a style='background-color: blue;' href='download.php?bid=".$row['bid']."' class='btn btn-danger'>Download</a> ";

  echo "</td>";

    echo "</tr>";
}
    echo "</table>";

}
}
    /*if button is not pressed.*/
else
{
$res=mysqli_query($db,"SELECT * FROM `books` ORDER BY `books`.`name` ASC;");

echo "<table class='table table-bordered table-hover'>";
echo "<tr style='background-color: gray;'>";
//Table Header
echo "<th>";    echo "ID";          echo "</th>";
echo "<th>";    echo "Book-Name";   echo "</th>";
echo "<th>";    echo "Author-Name"; echo "</th>";
echo "<th>";    echo "Edition";    echo "</th>";
echo "<th>";    echo "Status";     echo "</th>";
echo "<th>";    echo "Quantity";   echo "</th>";
echo "<th>";    echo "Action";   echo "</th>";



echo "</tr>";

while($row=mysqli_fetch_assoc($res))
{
    echo "<tr>";

    echo "<td>";    echo $row['bid'];    echo "</td>";
    echo "<td>";    echo $row['name'];   echo "</td>";
    echo "<td>";    echo $row['author']; echo "</td>";
    echo "<td>";    echo $row['edition'];echo "</td>";
    echo "<td>";    echo $row['status']; echo "</td>";
    echo "<td>";    echo $row['quantity']; echo "</td>";
   
    echo "<td>";    
    echo "<a style='background-color: blue;' href='view_book.php?bid=".$row['bid']."' class='btn btn-danger'>view</a> ";
    echo "<a style='background-color: red;' href='request.php?bid=".$row['bid']."' class='btn btn-danger'>Request</a> ";
    echo "<a style='background-color: blue;' href='download.php?bid=".$row['bid']."' class='btn btn-danger'>Download</a> ";

  echo "</td>";
    echo "</tr>";
}
    echo "</table>";
}
if(isset($_POST['submit1']))
{
    if(isset($_SESSION['login_user']))
    {
        mysqli_query($db, "INSERT INTO issue_book VALUES('$_SESSION[login_user]','$_POST[bid]','','','') ;");

        ?>
        <script type="text/javascript">
            window.location="request.php";
        
        </script>
        <?php

    }
    else
    {
        ?>
        <script type="text/javascript">
            alert("You must Login to Request book");
        </script>
        <?php
    }
}

?>
</div>
</div>
    </div>
   
</body>
</html>
      