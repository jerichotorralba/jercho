<?php
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="style/css" href="style.css">
    <meta charset="utf-8">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Registration</title>
</head>

</head>
<style>
    
/*
html5doctor.com Reset Stylesheet
v1.6.1
Last Updated: 2010-09-17
Author: Richard Clark - http://richclarkdesign.com
Twitter: @rich_clark
*/
html, body, div, span, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
abbr, address, cite, code,
del, dfn, em, img, ins, kbd, q, samp,
small, strong, sub, sup, var,
b, i,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, figcaption, figure,
footer, header, hgroup, menu, nav, section, summary,
time, mark, audio, video {
    margin:0;
    padding:0;
    border:0;
    outline:0;
    font-size:100%;
    vertical-align:baseline;
    background:transparent;
}

body {
    line-height:1;
}

article,aside,details,figcaption,figure,
footer,header,hgroup,menu,nav,section {
    display:block;
}

nav ul {
    list-style:none;
}

blockquote, q {
    quotes:none;
}

blockquote:before, blockquote:after,
q:before, q:after {
    content:'';
    content:none;
}

a {
    margin:0;
    padding:0;
    font-size:100%;
    vertical-align:baseline;
    background:transparent;
}

/* change colours to suit your needs */
ins {
    background-color:#ff9;
    color:#000;
    text-decoration:none;
}

/* change colours to suit your needs */
mark {
    background-color:#ff9;
    color:#000;
    font-style:italic;
    font-weight:bold;
}

del {
    text-decoration: line-through;
}

abbr[title], dfn[title] {
    border-bottom:1px dotted;
    cursor:help;
}

table {
    border-collapse:collapse;
    border-spacing:0;
}

/* change border colour to suit your needs */
hr {
    display:block;
    height:1px;
    border:0;  
    border-top:1px solid #cccccc;
    margin:1em 0;
    padding:0;
}

input, select {
    vertical-align:middle;
}

/*----------------------Main code INDEX-----------------------------------*/

.wrapper
{
    height: 660px;
    width: 1000px;
}
header{
height: 131px;
width: 1000px;
padding: 10px;
}

section{
    margin-top: -70px;
    height: 1000px;
    width: 1000;
    background: gray;  
}

.logo{
    float :left;
    padding-left:20px;
}
.logo img{
    padding-left: 80px;
}
li a{
color: white;
text-decoration: none;
}

section .sec_img{
    height: 550px;
    margin-top: 0px;
}
.box2{
    height: 850px;
    width: 400px;
    background-color: white;
    margin: 70px auto;
    color: black;
    padding: 20px;
}
button{
color: black;
}

input{
    height: 25px;
    width: 200px;
}

form .login{
    margin: auto 70px;
}
label{
    font-size: 12px;

}

/*--User Registration--*/

    </style>

<body>
   
<section>
<div class="reg_img"><br><br><br><br>
<div class="box2">
    <h1 style="text-align: center; font-size: 25px; color: black;"> &nbsp &nbsp Library Management System</h1><br>
    <h1 style="text-align: center; font-size: 25px; color: black;">Registration Now</h1><br><br>

    <form name="registration" action=""method="post">
        
    <div class="login">
    <label><h4><b>First Name: </b></h4></label>
    <input class="form-control" type="text" name="firstName" required=""><br>
    <label><h4><b>Last Name: </b></h4></label>
    <input class="form-control"type="text" name="lastname" required=""><br>
    <label><h4><b>UserName: </b></h4></label>
    <input class="form-control"type="text" name="username" required=""><br>
    <label><h4><b>Password: </b></h4></label>
    <input class="form-control"type="password" name="password"  required=""><br>
    <label><h4><b>Email: </b></h4></label>
    <input class="form-control"type="text" name="email"  required=""><br>
    <label><h4><b>Contact: </b></h4></label>
    <input class="form-control"type="text" name="contact"  required=""><br>
    <label><h4><b>Complete Address: </b></h4></label>
    <input class="form-control"type="text" name="address"  required=""><br>
    <label><h4><b>Date of birth: </b></h4></label>
    <input class="form-control"type="date" name="birth"  required=""><br>
    <label><h4><b>Gender: </b></h4></label>
    <input class="form-control"type="text" name="gender"  required=""><br>


    <center><input class="btn btn-default" type="submit" name="submit" value="Sign Up" style="color:black; width: 70px; height:30px;"></div><br></center>
    <center>You have an Account?<a style="color: blue;" href="user_login.php">&nbsp login</a></center>

    </form>
</div>
</section>

<?php

    if(isset($_POST['submit']))
    {
    
        $count=0;
        $sql="SELECT username FROM `user`";
        $res=mysqli_query($db,$sql);
        
        while($row=mysqli_fetch_assoc($res))
        {
            if($row['username']==$_POST['username'])
            {
                $count=$count+1;
            }
        }
        if($count==0)

        {
            mysqli_query($db,"INSERT INTO `user` VALUES('$_POST[firstName]', '$_POST[lastname]', 
        '$_POST[username]', '$_POST[password]','$_POST[email]','$_POST[contact]', '$_POST[address]', '$_POST[birth]', '$_POST[gender]')") or die(mysqli_error($db));

?>
    <script type="text/javascript">
        alert("Registration Successful");
        </script>
        
<?php
        }
        else{ 
            ?>
            <script type="text/javascript">
                alert("The username Already Exist.");
                </script> 
                <?php
                }

    }

?>

</body>