<?php

    include "connection.php";
    include "navbar.php";
    if(!$_SESSION['login_user']){
    header("location:user_login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="style/css" href="style.css">

    <title>Profile</title>

    <style type="text/css">
        .wrapper{
            width: 400px;
            margin: 0 auto;
            background-color: white;
            color: black;
        }
    
    </style>
</head>
<body style= "background-color: gray;">
<div class="container">
    <form action="" method="post">
    <button class="btn btn-default" style= "width: 70px; background-color: blue; color: white; margin-top: 20px;" name="submit2">Back</button>
        <button class="btn btn-default" style= "float: right; width: 70px; background-color: blue; color: white; margin-top: 20px;" name="submit1">Edit</button>
    </div>
</form>


    <div class="wrapper">
    <?php

if(isset($_POST['submit2']))
{
    ?>
    <script type="text/javascript">
        window.location="books.php"
    </script>

    <?php
}
    if(isset($_POST['submit1']))
    {
        ?>

        <script type="text/javascript">
            window.location="edit.php"
        </script>
            
        <?php
    }
    $q=mysqli_query($db, "SELECT * FROM user where username='$_SESSION[login_user]';");

        ?>
        <h2 style= "text-align: center;">My Profile</h2>
        <?php

        $row=mysqli_fetch_assoc($q);


        ?>
        <div style="text-align: center;"><b>Welcome</b>

        <h4> 
            <?php echo $_SESSION['login_user']; ?>
        </h4>
    </div>
        <?php

        echo"<b>";
        echo "<table class='table table-bordered style: height: 100px;'>";
        echo "<tr>";
         echo "<td>";
            echo "<b> First Name: </b>";
         echo "</td>";

         echo "<td>";
            echo $row['firstName'];
         echo "</td>";
    echo "</tr>";

    echo "<tr>";
        
        echo "<td>";
        echo "<b> Last Name: </b>";
        echo "</td>";

        echo "<td>";
        echo $row['lastname'];
        echo "</td>";

    echo "</tr>";

    echo "<tr>";

        echo "<td>";
        echo "<b> Username: </b>";
        echo "</td>";

        echo "<td>";
        echo $row['username'];
        echo "</td>";

    echo "</tr>";

    echo "<tr>";
        echo "<td>";
        echo "<b> Password: </b>";
        echo "</td>";

        echo "<td>";
        echo $row['password'];
       echo "</td>";

    echo "</tr>";


    echo "<tr>";
        echo "<td>";
        echo "<b> email: </b>";
        echo "</td>";

        echo "<td>";
        echo $row['email'];
        echo "</td>";
    echo "</tr>";

    echo "<tr>";
        echo "<td>";
        echo "<b> contact </b>";
        echo "</td>";

        echo "<td>";
        echo $row['contact'];
        echo "</td>";
    echo "</tr>";

    echo "<tr>";
    echo "<td>";
    echo "<b> address </b>";
    echo "</td>";

    echo "<td>";
    echo $row['address'];
    echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "<b> birth </b>";
echo "</td>";

echo "<td>";
echo $row['birth'];
echo "</td>";
echo "</tr>";


echo "<tr>";
echo "<td>";
echo "<b> gender </b>";
echo "</td>";

echo "<td>";
echo $row['gender'];
echo "</td>";
echo "</tr>";


    

echo "</table>";
echo"</b>";
        ?>
</div>
</body>
</html>