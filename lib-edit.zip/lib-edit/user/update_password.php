<?php

include "connection.php";
include "navbar.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>

    <style type="text/css">
        body{
          
            height: 550px;
            
        }
        .wrapper{
            width: 400px;
            height: 300px;
            margin: 100px auto;
            background-color: blue;
            color: white;
            padding: 27px 15px;
        }
        .form-control{ 
            width: 300px;
        }
        input{
    height: 35px;
    width: 100px;
}
button{
   margin-left: 122px;
}
    </style>

</head>
<body>
    <div class="wrapper">
        <div style="text-align: center;">
    <h1 style="text-align: center; font-size:30px;"> Change Your Password</h1>
    </div>
    <div style="padding-left: 30px;">
    <form action="" method="post">
        <input class="form-control" type="text" name="username" class="form-control" placeholder="Username" required=""><br><br>
        <input class="form-control"type="text" name="email" class="form-control" placeholder="Email" required=""><br><br>
        <input class="form-control" type="text" name="password" class="form-control" placeholder="New Password" required=""><br><br>
        <button class="btn btn-default" type="submit" name="submit">Update</button>
    
    </div>
    </div>
    <?php

    if(isset($_POST['submit']))
    {
        if(mysqli_query($db, "UPDATE user SET password='$_POST[password]' WHERE username='$_POST[username]' && email='$_POST[email]' ;"))
        {
            ?>
            <script type="text/javascript">
                alert("The Password Updated Successfully.");
                </script>  
            <?php
            
        }
        ?>
           <script type="text/javascript">
        window.location="index.php"
        </script>
        <?php
    }

    ?>
</body>
</html>