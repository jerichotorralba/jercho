<?php
include "connection.php";
include "navbar.php";
if(!$_SESSION['login_user']){
    header("location:user_login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <title>FeedBack</title>
    <style type="text/css">
        body{

            background-image: url("images/66.jpg");
        }
        .wrapper {
            margin: -20px auto;
            padding: 10px;
            width: 900px;
            height: 600px;
            background-color: black;
            opacity: .8;
            color: white;
        }
        .form-control{
            height: 70px;
            width: 60%;
        }
        .scroll{
            width: 100%;
            height: 300px;
            overflow: auto;
        }
        
        </style>
</head>
<body>
    <div class="wrapper">
        <h4>If You Have Any Suggestion or Questions Please Comment Below.</h4>
        <form style="" action="" method="post">
            <input class="form-control" type=" text" name= "comment" placeholder="Write Something. . ."><br>
            <input class="btn btn-default" type="submit" name="submit" value="comment" style= "width: 100px height: 35px;">
          </form>
            
<br><br>
 <div class="scroll">
    <?php
  if(isset($_POST['submit']))
   {   $sql="INSERT INTO `comments` VALUES('','$_SESSION[login_user]','$_POST[comment]');";
     if(mysqli_query($db, $sql))
     {
       $q="SELECT * FROM `comments` ORDER BY `comments`.`id`DESC";
         $res=mysqli_query($db,$q);

        echo "<table class='table table-bordered'>";
          while ($row=mysqli_fetch_assoc($res)) 
          {
         echo "<tr>";
       echo "<td>"; echo $row['username']; echo "</td>";
         echo "<td>"; echo $row['comment']; echo "</td>";
             echo "</tr>";

      }
      echo "</table>";
     }
     }
    else{
  $q="SELECT * FROM `comments` ORDER BY `comments`.`id` DESC";
      $res=mysqli_query($db,$q);
     echo "<table class='table table-bordered'>";
  while ($row=mysqli_fetch_assoc($res)) 
     {
       echo "<tr>";
       echo "<td>"; echo $row['username']; echo "</td>";
        echo "<td>"; echo $row['comment']; echo "</td>";
        echo "</tr>";
        }
        echo "</table>";
    }
   ?>
   </div>
     </div>
</body>
</html>
      