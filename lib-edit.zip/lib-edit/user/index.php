<?php

session_start();
if(!$_SESSION['login_user']){
    header("location:user_login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="style/css" href="style.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <title>Library Management System</title>

</head>
<style>
    
/*
html5doctor.com Reset Stylesheet
v1.6.1
Last Updated: 2010-09-17
Author: Richard Clark - http://richclarkdesign.com
Twitter: @rich_clark
*/
html, body, div, span, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
abbr, address, cite, code,
del, dfn, em, img, ins, kbd, q, samp,
small, strong, sub, sup, var,
b, i,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, figcaption, figure,
footer, header, hgroup, menu, nav, section, summary,
time, mark, audio, video {
    margin:0;
    padding:0;
    border:0;
    outline:0;
    font-size:100%;
    vertical-align:baseline;
    background:transparent;
}

body {
    line-height:1;
}

article,aside,details,figcaption,figure,
footer,header,hgroup,menu,nav,section {
    display:block;
}

nav ul {
    list-style:none;
}

blockquote, q {
    quotes:none;
}

blockquote:before, blockquote:after,
q:before, q:after {
    content:'';
    content:none;
}

a {
    margin:0;
    padding:0;
    font-size:100%;
    vertical-align:baseline;
    background:transparent;
}

/* change colours to suit your needs */
ins {
    background-color:#ff9;
    color:#000;
    text-decoration:none;
}

/* change colours to suit your needs */
mark {
    background-color:#ff9;
    color:#000;
    font-style:italic;
    font-weight:bold;
}

del {
    text-decoration: line-through;
}

abbr[title], dfn[title] {
    border-bottom:1px dotted;
    cursor:help;
}

table {
    border-collapse:collapse;
    border-spacing:0;
}

/* change border colour to suit your needs */
hr {
    display:block;
    height:1px;
    border:0;  
    border-top:1px solid #cccccc;
    margin:1em 0;
    padding:0;
}

input, select {
    vertical-align:middle;
}

/*----------------------Main code INDEX-----------------------------------*/

.wrapper
{
    
    height: 650px;
    width: 1350px;
    background-color: none;
}
header{
height: 90px;
width: 1367px;
background: black;
padding: 10px;
}

section{
    height: 550px;
    width: 1361px;
    background: white;  
}

.logo{
    float :left;
    padding-left:20px;
}
.logo img{
    padding-left: 120px;
}
li a{
color: white;
text-decoration: none;
}
nav{
    float: right;
    word-spacing: 30px;
    padding: 20px
}
nav li{
    display: inline-block;
    line-height: 80px;
}
section{
    margin-top: -47px;
    background-image: url("images/libIndex.jpg");
}
.box{
    height: 300px;
    width: 450px;
    background-color: #1e1d1d;
    margin: 70px auto;
    opacity: .8;
    color: white;
}

/*--user_login--*/




    </style>

<body>
      <div class="wrapper">
        <header>
        <div class="logo">
</div>

<?php
    if(isset($_SESSION['login_user']))
    {?>
        <nav>
            <ul>
             <li><a href="books.php">Dashboard</a></li>
             </ul>
        </nav>
    <?php

    }

    else{
        ?>
            <nav>
                <ul>
            
                    <li><a href="books.php">Dashboard</a></li>
                    </li>
                </ul>
            </nav>
         <?php
          }
    
?>
            
        </header>
        <br><br><br>
        <section>
            <br><br><br>
             <div>
                <div class="box">
                    <br><br><br><br>
                   <h1 style="text-align: center;font-size: 35px;">Welcome To Library</h1><br><br>
                    <h1 style="text-align: center;font-size: 25px;">Open at 8:00 AM</h1><br>
                    <h1 style="text-align: center;font-size: 25px;">Close at 5:00 PM</h1>
            </div>

                </div>
         
        </section>
        <footer>

        </footer>

     </div>

     <?php
    include "footer.php";

     ?>
</body>
</html>