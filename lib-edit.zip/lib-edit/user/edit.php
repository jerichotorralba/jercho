<?php
include "navbar.php";
include "connection.php";
if(!$_SESSION['login_user']){
    header("location:user_login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>

    <style type="text/css">
        body{
            background-color: gray;
        }
        .form-control{
        background-color: none;
           width: 250px;
           height: 35px;
                
        }
        form{
            padding-left: 570px;
        }
        label{
            color: black;
        }
       
    </style>

</head>
<body>
<br><br>
<h2 style="text-align: center; color: black;">Edit Profile</h2>
<?php

        $sql = "SELECT * FROM user WHERE username='$_SESSION[login_user]'";
        $result = mysqli_query($db, $sql) or die (mysqli_error());

        while ($row = mysqli_fetch_assoc($result))
        {
          
            $firstName=$row['firstName'];
            $lastname=$row['lastname'];
            $username=$row['username'];
            $password=$row['password'];
            $email=$row['email'];
            $contact=$row['contact'];
            $address=$row['address'];
            $birth=$row['birth'];
            $gender=$row['gender'];

        }

?>
    
 <div class="profile_info" style="text-align: center;">
        <span style="color: black; font-size: 20px;">Welcome</span>
        <h4 style="color: black;"><?php echo $_SESSION['login_user']; ?></h4>
    </div>

    <form action="" method="post" enctype="multipart/form-data">

        <label><h4><b>First Name: </b></h4></label>
        <input class="form-control" type="text" name="firstname" value="<?php echo $firstName; ?>">
        <label><h4><b>Last Name: </b></h4></label>
        <input class="form-control" type="text" name="lastname" value="<?php echo $lastname; ?>">
        <label><h4><b>Username: </b></h4></label>
        <input class="form-control" type="text" name="username"value="<?php echo $username; ?>">
        <label><h4><b>Password: </b></h4></label>
        <input class="form-control" type="text" name="password"value="<?php echo $password; ?>">
        <label><h4><b>Email: </b></h4></label>
        <input class="form-control" type="text" name="email"value="<?php echo $email; ?>">
        <label><h4><b>Contact: </b></h4></label>
        <input class="form-control" type="text" name="contact"value="<?php echo $contact; ?>"><br>
        <label><h4><b>Address: </b></h4></label>
        <input class="form-control" type="text" name="address"value="<?php echo $address; ?>"><br>
        <label><h4><b>Date of birth: </b></h4></label>
        <input class="form-control" type="text" name="birth"value="<?php echo $birth; ?>"><br>
        <label><h4><b>Gender:  </b></h4></label>
        <input class="form-control" type="text" name="gender"value="<?php echo $gender; ?>"><br>
        
        <div style="padding-left: 70px;"><button class="btn btn-default" type="submit" name="submit">Update Profile</button></div><br><br><br>
    </form>
<?php

if(isset($_POST['submit']))
{
    $firstName=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $email=$_POST['email'];
    $contact=$_POST['contact'];
    $address=$_POST['address'];
    $birth=$_POST['birth'];
    $gender=$_POST['gender'];


    $sql1= "UPDATE user SET firstname='$firstName', lastname='$lastname', username='$username', password='$password' , email='$email', contact = '$contact', address = '$address', birth = '$birth', gender = '$gender' WHERE username= '".$_SESSION['login_user']."';";

    if(mysqli_query($db,$sql1))
    {
        ?>
        <script type="text/javascript">
            alert("Update Successfully!");
            window.location="profile.php";
        </script>
        <?php
    }
}
?>
</body>
</html>