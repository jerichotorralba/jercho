<?php
include "connection.php";
include "navbar.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Request</title>
    <style type="text/css">
        .srch{
            padding-left: 78%;
        }
        .form-control
          {
            width: 250px;
            height: 30px;
          }
        body {
            background-color: gray;
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}

.sidenav {
  height: 100%;
  margin-top: 50px;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #222;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding-left: 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.image-circle{
    margin-left: 60px;

}
.h:hover{
    color: white;
    width: 300px;
    height: 50px;
    background-color: white;
}
.container{
    height: 550px;
    width: 85%;
    background-color: white;
    color: black;
    margin-top: -60px;
}
.scroll{
  width: 100%;
  height: 400px;
  overflow: auto;
}
th,td{
  width: 10%;
}

    </style>
</head>
<body>
    <!---sidenav--->
        
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

  <div style="color: white; margin-left: 60px; font-size: 20px;">

       <?php
       if(isset($_SESSION['login_admin']))
          {echo "<img class='img-circle profile_img'height=50 width=50 src='images/".$_SESSION['pic']."'>";
          echo "</br></br>";
           echo   " Welcome<br>".$_SESSION['login_admin'];
          }
          ?>

 </div><br><br>

 <div class="h"><a style="font-size: 15px;" href="index.php">Home</a></div>
 <div class="h"><a style="font-size: 15px;" href="books.php">Books</a></div>
  <div class="h"><a style="font-size: 15px;" href="feedback.php">Feedback</a></div>
  <div class="h"><a style="font-size: 15px;" href="profile.php">Profile</a></div>
  <div class="h"><a style="font-size: 15px;" href="user.php">User Details</a></div>
  <div class="h"><a style="font-size: 15px;" href="addbook.php">Add Books</a></div>
  <div class="h"><a style="font-size: 15px;" href="request.php">Book Request</a></div>
  <div class="h"><a style="font-size: 15px;" href="issue_info.php">Issued Information</a></div>
  <div class="h"><a style="font-size: 15px;" href="logout.php">logout</a></div>
</div>

<div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>


<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "gray";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "gray";
}
</script>
<div class="container">
  
    <?php

    if(isset($_SESSION['login_admin']))
    {
    ?>
    <div style="float: left; padding: 25px;">
      <form method="post" action="">
       <button name="submit2" type="submit" class="btn btn-default" style="background-color: #06861a; color: yellow;">RETURN</button> &nbsp &nbsp
       <button name="submit3" type="submit" class="btn btn-default" style="background-color: red; color: yellow;">EXPIRED</button>
    </div>
      </form>
         <div class="srch">
         <form method="post" action="" name="from1"><br>
             <input type="text" name="username" class="form-control" placeholder="Username" required=""><br>
              <input type="text" name="bid" class="form-control" placeholder="BID" required=""><br>
              <button  style="background-color: blue; color: white;"class="btn btn-default" name="submit" type="submit">Submit</button>
         </form>
         </div>
         <div class="scroll">
    <?php
    
    if(isset($_POST['submit']))
    {
    $var1='<p style="color:yellow; background-color:green;">RETURNED</p>';
    mysqli_query($db, "UPDATE issue_book SET approve='$var1' where username='$_POST[username]' and bid='$_POST[bid]';");
   
    mysqli_query($db, "UPDATE books SET quantity = quantity+1 where bid='$_POST[bid]'");
  }
    }
    ?>
    <!--<h3 style="text-align: center;">Date Expred List</h3><br>--><br>
    <?php
    $c=0;
    if(isset($_SESSION['login_admin']))
    {

      $ret='<p style="color:yellow; background-color:green;">RETURNED</p>';
      $exp='<p style="color:yellow; background-color:red;">EXPIRED</p>';

      if(isset($_POST['submit2']))
      {
        $sql="SELECT user.username,books.bid,
        name,author,edition,approve,issue,issue_book.return FROM user inner join 
        issue_book ON user.username=issue_book.username inner join books 
        ON issue_book.bid=books.bid WHERE issue_book.approve = '$ret' ORDER BY `issue_book`.`return` DESC";

        $res=mysqli_query($db,$sql);
      }
      else if(isset($_POST['submit3']))
      {
        $sql="SELECT user.username,books.bid,
        name,author,edition,approve,issue,issue_book.return FROM user inner join 
        issue_book ON user.username=issue_book.username inner join books 
        ON issue_book.bid=books.bid WHERE issue_book.approve = '$exp' ORDER BY `issue_book`.`return` DESC";

        $res=mysqli_query($db,$sql);
      }
      else
      {
        $sql="SELECT user.username,books.bid,
        name,author,edition,approve,issue,issue_book.return FROM user inner join 
        issue_book ON user.username=issue_book.username inner join books 
        ON issue_book.bid=books.bid WHERE issue_book.approve != '' and issue_book.approve !='Yes'  ORDER BY `issue_book`.`return` DESC";
        
        $res=mysqli_query($db,$sql);
      }


      echo "<table class='table table-bordered' style='width: 100%;'>";
      //Table Header
       echo "<tr style='background-color: gray;'>";
      echo "<th>";    echo "Username";       echo "</th>";
      echo "<th>";    echo "BID";         echo "</th>";
      echo "<th>";    echo "Book Name";          echo "</th>";
      echo "<th>";    echo "Author Name";         echo "</th>";
      echo "<th>";    echo "Edition";         echo "</th>";
      echo "<th>";    echo "Status";         echo "</th>";
      echo "<th>";    echo "Issue Date";         echo "</th>";
      echo "<th>";    echo "Return Date";         echo "</th>";
      echo "<th>";    echo "Action";         echo "</th>";
      
      echo "</tr>";
      echo "</table>";
      echo "<div class='scroll'>";
      echo "<table class='table table-bordered'>";
      while($row=mysqli_fetch_assoc($res))
      {
        
          echo "<tr>";
          echo "<td>";    echo $row['username'];    echo "</td>";
          echo "<td>";    echo $row['bid'];    echo "</td>";
          echo "<td>";    echo $row['name'];    echo "</td>";
          echo "<td>";    echo $row['author'];    echo "</td>";
          echo "<td>";    echo $row['edition'];    echo "</td>";
          echo "<td>";    echo $row['approve'];    echo "</td>";
          echo "<td>";    echo $row['issue'];    echo "</td>";
          echo "<td>";    echo $row['return'];    echo "</td>";
         
          echo "</tr>";
      }
          echo "</table>"; 
          echo "</div>";
    }
    else{
      ?>

<h3 style="text-align: center;">Login to see information of Borrowed Books</h3><br>

      <?php
    }


    ?>
</div>
</body>
</html>