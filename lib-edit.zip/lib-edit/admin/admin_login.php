<?php
include "connection.php";
include "navbar.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="style/css" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Admin Login</title>
</head>
<style>
    
/*
html5doctor.com Reset Stylesheet
v1.6.1
Last Updated: 2010-09-17
Author: Richard Clark - http://richclarkdesign.com
Twitter: @rich_clark
*/
html, body, div, span, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
abbr, address, cite, code,
del, dfn, em, img, ins, kbd, q, samp,
small, strong, sub, sup, var,
b, i,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, figcaption, figure,
footer, header, hgroup, menu, nav, section, summary,
time, mark, audio, video {
    margin:0;
    padding:0;
    border:0;
    outline:0;
    font-size:100%;
    vertical-align:baseline;
    background:transparent;
}

body {
    line-height:1;
}

article,aside,details,figcaption,figure,
footer,header,hgroup,menu,nav,section {
    display:block;
}

nav ul {
    list-style:none;
}

blockquote, q {
    quotes:none;
}

blockquote:before, blockquote:after,
q:before, q:after {
    content:'';
    content:none;
}

a {
    margin:0;
    padding:0;
    font-size:100%;
    vertical-align:baseline;
    background:transparent;
}

/* change colours to suit your needs */
ins {
    background-color:#ff9;
    color:#000;
    text-decoration:none;
}

/* change colours to suit your needs */
mark {
    background-color:#ff9;
    color:#000;
    font-style:italic;
    font-weight:bold;
}

del {
    text-decoration: line-through;
}

abbr[title], dfn[title] {
    border-bottom:1px dotted;
    cursor:help;
}

table {
    border-collapse:collapse;
    border-spacing:0;
}

/* change border colour to suit your needs */
hr {
    display:block;
    height:1px;
    border:0;  
    border-top:1px solid #cccccc;
    margin:1em 0;
    padding:0;
}

input, select {
    vertical-align:middle;
}

/*----------------------Main code INDEX-----------------------------------*/

.wrapper
{
    height: 660px;
    width: 1350px;
}
header{
height: 131px;
width: 1340px;
background: black;
padding: 10px;
}

section{
    margin-top: -20px;
    height: 700px;
    width: 1361px;
    background: gray;  
}
footer{
    height: 82px;
    width: 1361px;
    background: black;
}
.logo{
    float :left;
    padding-left:20px;
}
.logo img{
    padding-left: 80px;
}
li a{
color: white;
text-decoration: none;
}

section .sec_img{
    height: 550px;
    margin-top: 0px;
}
.box1{
    height: 350px;
    width: 450px;
    background-color: white;
    margin: 70px auto;
    color: black;
    padding: 20px;
}


.log_img{
    height: 650px;
    margin-top: 0px;
}
input{
    height: 25px;
    width: 200px;
}

form .login{
    margin: auto 70px;
}

/*--admin_login--*/




    </style>

<body>
  
<section>
<div class="log_img">
<br><br><br>
<div class="box1">
<br><br><br>
    <h1 style="text-align: center; font-size:25px;">Admin Login Form</h1><br><br>
    <form name="login" action=""method="post">
    <div class="login">
    <input style=""class="form-control" type="text" name="username" placeholder="Username" required=""><br>
    <input class="form-control"type="password" name="password" placeholder="Password" required=""><br>
    <center><input class="btn btn-default" type="submit" name="submit" value="Login" style="background-color: blue; color:white; width: 60px; height:40px;"></input></center>
    </div> 
    </form>

</div>
</section>
    <?php
    if(isset($_POST['submit']))
    {
        $count=0;
        $res=mysqli_query($db,"SELECT * FROM `admin` WHERE username='$_POST[username]' && password='$_POST[password]';");

        $row= mysqli_fetch_assoc($res);

        $count=mysqli_num_rows($res);


        if($count==00)
        {
            ?>
                   
                <script type="text/javascript">
                alert("The username and password doesn't match.");
                </script>  
               
           <!-- <div class="alert alert-danger" style="width:700px; margin-left:300px; background-color: #d52222; color: white;">
                <strong>The username and password doesn't match.</strong>
            </div> -->
    <?php
        }
        else{
            /*--if username & password matches--*/ 
        $_SESSION['login_admin'] = $_POST['username'];
        $_SESSION['pic']=$row['pic'];
        
            ?>
        <script type="text/javascript">
        window.location="books.php"
        </script>
        
<?php
            
        }


    }



    ?>
</body>
</html>