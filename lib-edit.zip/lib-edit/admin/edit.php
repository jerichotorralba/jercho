<?php
include "navbar.php";
include "connection.php";
if(!$_SESSION['login_admin']){
    header("location:admin_login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>

    <style type="text/css">

        .form-control{
           width: 250px;
           height: 35px;
                
        }
        form{
            padding-left: 570px;
        }
        label{
            color: black;
        }

        
    </style>

</head>
<body>
<br><br>
<h2 style="text-align: center; color: black;">Edit Profile</h2>
<?php

        $sql = "SELECT * FROM admin WHERE username='$_SESSION[login_admin]'";
        $result = mysqli_query($db, $sql) or die (mysqli_error());

        while ($row = mysqli_fetch_assoc($result))
        {
          
            $firstName=$row['firstname'];
            $lastname=$row['lastname'];
            $username=$row['username'];
            $password=$row['password'];
            $email=$row['email'];
            $contact=$row['contact'];

        }

?>

 <div class="profile_info" style="text-align: center;">
        <span style="color: black;">Welcome</span>
        <h4 style="color: black;"><?php echo $_SESSION['login_admin']; ?></h4>
    </div> <br><br>

    <form action="edit" method="post" enctype="multipart/form-data">

        <input class="form-control" type="file" name="file">

        <label><h4><b>First Name: </b></h4></label>
        <input class="form-control" type="text" name="firstname" value="<?php echo $firstName; ?>">
        <label><h4><b>Last Name: </b></h4></label>
        <input class="form-control" type="text" name="lastname" value="<?php echo $lastname; ?>">
        <label><h4><b>Username: </b></h4></label>
        <input class="form-control" type="text" name="username"value="<?php echo $username; ?>">
        <label><h4><b>Password: </b></h4></label>
        <input class="form-control" type="text" name="password"value="<?php echo $password; ?>">
        <label><h4><b>Email: </b></h4></label>
        <input class="form-control" type="text" name="email"value="<?php echo $email; ?>">
        <label><h4><b>Contact: </b></h4></label>
        <input class="form-control" type="text" name="contact"value="<?php echo $contact; ?>"><br>
        <label><h4><b>Contact: </b></h4></label>
        <input class="form-control" type="text" name="contact"value="<?php echo $contact; ?>"><br>
        <div style="padding-left: 70px;"><button class="btn btn-default" type="submit" name="submit">Update Profile</button></div><br><br><br>
    </form>
<?php

if(isset($_POST['submit']))
{
    move_uploaded_file($_FILES['file']['tmp_name'],"images/".$_FILES['file']['name']);
    $firstName=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $email=$_POST['email'];
    $contact=$_POST['contact'];
    $pic=$_FILES['file']['name'];

    $sql1= "UPDATE admin SET pic='$pic', firstname='$firstName', lastname='$lastname', username='$username',password='$password', email='$email', contact='$contact' WHERE username= '".$_SESSION['login_admin']."';";

    if(mysqli_query($db,$sql1))
    {
        ?>
        <script type="text/javascript">
            alert("Update Successfully!");
            window.location="profile.php";
        </script>
        <?php
    }
}


 
?>
</body>
</html>