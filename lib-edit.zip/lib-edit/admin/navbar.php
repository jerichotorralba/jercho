<?php

session_start();
if(isset($_SESSION['login_admin']))
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

        
    <title>Library Management System</title>
</head>
<style>

</style>
<body>
    
</body>
</html>
        <nav class="navbar navbar-inverse">
            
            
  <a style="color: white; padding-left: 450px;" class="navbar-brand active">LIBRARY MANAGEMENT SYSTEM WITH DIGITAL LIBRARY</a>

    </div>

        
     
                <?php

                if(isset($_SESSION['login_admin']))
                
                {?>
                     

                <ul class="nav navbar-nav navbar-right">
                    <li> <a href="profile.php">
                    <div style="color: white; margin-right: 10px;">

                         <?php
                         echo "<img class='img-circle profile_img'height=30 width=30 src='images/".$_SESSION['pic']."'>";
                         echo   " ".$_SESSION['login_admin'];
                           ?>
                    </div>
                    </a></li>
                    
                </ul>
                  <?php 
                }
                ?>
                   </div>
            </nav>
           
           
           
</ul>
</body>
</html>