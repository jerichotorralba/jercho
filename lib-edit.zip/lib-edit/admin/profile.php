<?php

    include "connection.php";
    include "navbar.php";
    if(!$_SESSION['login_admin']){
    header("location:admin_login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="style/css" href="style.css">

    <title>Profile</title>

    <style type="text/css">
        .wrapper{
            width: 300px;
            margin: 0 auto;
            color: black;
        }
    
    </style>
</head>
<body style= "background-color: white;">
<div class="container">
    <form action="" method="post">
        <button class="btn btn-default" style= "width: 70px;background-color: blue; color: white;" name="submit2" type="submit">Back</button>
        <button class="btn btn-default" style= "float: right; width: 70px;background-color: blue; color: white;" name="submit1" type="submit">Edit</button>
    </div>
</form>


    <div class="wrapper">
    <?php

if(isset($_POST['submit2']))
{
    ?>
    <script type="text/javascript">
        window.location="books.php"
    </script>

    <?php
}
        
       

        if(isset($_POST['submit1']))
        {
            ?>
            <script type="text/javascript">
                window.location="edit.php"
            </script>

            <?php
        }


    $q=mysqli_query($db, "SELECT* FROM admin where username='$_SESSION[login_admin]';");

        ?>
        <h2 style= "text-align: center;">My Profile</h2>
        <?php

        $row=mysqli_fetch_assoc($q);

        echo "<div style='text-align: center'>
        <img class='img-circle profile_img' height= 110 width 120 src='images/".$_SESSION['pic']."'>
        </div>";

        ?>
        <div style="text-align: center;"><b>Welcome</b>

        <h4> 
            <?php echo $_SESSION['login_admin']; ?>
        </h4>
    </div>
        <?php

        echo"<b>";
echo "<table class='table table-bordered'>";
    echo "<tr>";
         echo "<td>";
            echo "<b> First Name: </b>";
         echo "</td>";

         echo "<td>";
            echo $row['firstname'];
         echo "</td>";
    echo "</tr>";

    echo "<tr>";
        
        echo "<td>";
        echo "<b> Last Name: </b>";
        echo "</td>";

        echo "<td>";
        echo $row['lastname'];
        echo "</td>";

    echo "</tr>";

    echo "<tr>";

        echo "<td>";
        echo "<b> Username: </b>";
        echo "</td>";

        echo "<td>";
        echo $row['username'];
        echo "</td>";

    echo "</tr>";


    echo "<tr>";
        echo "<td>";
        echo "<b> email </b>";
        echo "</td>";

        echo "<td>";
        echo $row['email'];
        echo "</td>";
    echo "</tr>";

    echo "<tr>";
        echo "<td>";
        echo "<b> contact </b>";
        echo "</td>";

        echo "<td>";
        echo $row['contact'];
        echo "</td>";
    echo "</tr>";

echo "</table>";
echo"</b>";
        ?>
</div>
 

   
</body>
</html>