<?php
include "connection.php";
include "navbar.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="style/css" href="style.css">
    <meta charset="utf-8">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Admin Registration</title>
</head>

</head>
<style>
    
/*
html5doctor.com Reset Stylesheet
v1.6.1
Last Updated: 2010-09-17
Author: Richard Clark - http://richclarkdesign.com
Twitter: @rich_clark
*/
html, body, div, span, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
abbr, address, cite, code,
del, dfn, em, img, ins, kbd, q, samp,
small, strong, sub, sup, var,
b, i,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, figcaption, figure,
footer, header, hgroup, menu, nav, section, summary,
time, mark, audio, video {
    margin:0;
    padding:0;
    border:0;
    outline:0;
    font-size:100%;
    vertical-align:baseline;
    background:transparent;
}

body {
    line-height:1;
}

article,aside,details,figcaption,figure,
footer,header,hgroup,menu,nav,section {
    display:block;
}

nav ul {
    list-style:none;
}

blockquote, q {
    quotes:none;
}

blockquote:before, blockquote:after,
q:before, q:after {
    content:'';
    content:none;
}

a {
    margin:0;
    padding:0;
    font-size:100%;
    vertical-align:baseline;
    background:transparent;
}

/* change colours to suit your needs */
ins {
    background-color:#ff9;
    color:#000;
    text-decoration:none;
}

/* change colours to suit your needs */
mark {
    background-color:#ff9;
    color:#000;
    font-style:italic;
    font-weight:bold;
}

del {
    text-decoration: line-through;
}

abbr[title], dfn[title] {
    border-bottom:1px dotted;
    cursor:help;
}

table {
    border-collapse:collapse;
    border-spacing:0;
}

/* change border colour to suit your needs */
hr {
    display:block;
    height:1px;
    border:0;  
    border-top:1px solid #cccccc;
    margin:1em 0;
    padding:0;
}

input, select {
    vertical-align:middle;
}

/*----------------------Main code INDEX-----------------------------------*/

.wrapper
{
    height: 660px;
    width: 1350px;
    background-color: red;
}
header{
height: 131px;
width: 1340px;
background: black;
padding: 10px;
}

section{
    margin-top: -70px;
    height: 550px;
    width: 1361px;
    background: grey;  
}
footer{
    height: 82px;
    width: 1361px;
    background: black;
}
.logo{
    float :left;
    padding-left:20px;
}
.logo img{
    padding-left: 80px;
}
li a{
color: white;
text-decoration: none;
}

.box2{
    height: 550px;
    width: 450px;
    background-color: black;
    margin: 70px auto;
    opacity: .6;
    color: white;
    padding: 20px;
}
button{
color: black;
}

.reg_img{
    height: 650px;
    margin-top: 0px;
    background-image: url("images/4.png");
}
input{
    height: 25px;
    width: 200px;
}

form .login{
    margin: auto 70px;
}


/*--User Registration--*/

    </style>

<body>
   
<section>
<div class="box2">
    <h1 style="text-align: center; font-size: 35px;"> &nbsp &nbsp Library Management System</h1><br>
    <h1 style="text-align: center; font-size: 25px;">Admin Registration Form</h1><br>

    <form name="Registration" action=""method="post">
        
        <div class="login">
        <label><h4><b>First Name: </b></h4></label>
    <input class="form-control" type="text" name="firstname" placeholder="FirstName" required=""><br>

    <input class="form-control"type="text" name="lastname" placeholder="LastName" required=""><br>

    <input class="form-control"type="text" name="username" placeholder="Username" required=""><br>

    <input class="form-control"type="password" name="password" placeholder="Password" required=""><br>

    <input class="form-control"type="text" name="email" placeholder="Email" required=""><br>

    <input class="form-control"type="text" name="contact" placeholder="Contact Number" required=""><br>

    <input style="background-color: blue;" class="btn btn-default" type="submit" name="submit" value="Sign Up" style="color:black; width: 70px; height:30px;"></div>

    </form>
</div>
</section>

<?php

    if(isset($_POST['submit']))
    {
    
        $count=0;
        $sql="SELECT username FROM `admin`";
        $res=mysqli_query($db,$sql);
        
        while($row=mysqli_fetch_assoc($res))
        {
            if($row['username']==$_POST['username'])
            {
                $count=$count+1;
            }
        }
        if($count==0)

        {mysqli_query($db,"INSERT INTO `admin` VALUES('','$_POST[firstname]', '$_POST[lastname]', 
        '$_POST[username]', '$_POST[password]', '$_POST[email]', '$_POST[contact]',);");

?>
    <script type="text/javascript">
        alert("Registration Successful");
        </script>
        
<?php
        }
        else{ 
            ?>
            <script type="text/javascript">
                alert("The username Already Exist.");
                </script> 
                <?php
                }
    }


?>





</body>